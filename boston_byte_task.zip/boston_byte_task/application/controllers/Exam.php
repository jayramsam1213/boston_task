<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Exam extends CI_Controller {
   /**
    * Get All Data from this method.
    *
    * @return Response
   */
   public function __construct() {
    //load database in autoload libraries 
      parent::__construct(); 
      $this->load->model('exam_model');         
   }
   public function index()
   {
      $this->load->view('includes/header');       
       $this->load->view('dashboard');
       $this->load->view('includes/footer');


   }
   public function subject()
   {
       $sub=new exam_model;
       $data['data']=$sub->get_subject();
       $this->load->view('includes/header');       
       $this->load->view('subject',$data);
       $this->load->view('includes/footer');
   }
   public function add_subject()
   {

       $this->load->view('includes/header');       
       $this->load->view('add_subject1');
       $this->load->view('includes/footer');

   }
    public function add_test()
   {
      $sub=new exam_model;
       $data['data']=$sub->getUserRoles();
       $this->load->view('includes/header');     
       $this->load->view('add_test',$data, NULL);
       $this->load->view('includes/footer');

   }
   public function add_question()
   {
      $sub=new exam_model;
       $data['data']=$sub->get_question();
       $this->load->view('includes/header');     
       $this->load->view('add_question',$data);
       $this->load->view('includes/footer');

   }


     public function post_test()
   {
       $sub=new exam_model;
       $sub->insert_test();
       redirect(base_url('exam/test_details'));
    }

 
      public function post_subject()
   {
       $sub=new exam_model;
       $sub->insert_subject();
       redirect(base_url('exam/subject'));
    }
    public function test_details()
   {
       $sub=new exam_model;
       $data['data']=$sub->get_test();
       $this->load->view('includes/header');       
       $this->load->view('test',$data);
       $this->load->view('includes/footer');
   }
      public function question_details()
   {
       $sub=new exam_model;
       $data['data']=$sub->get_question();
       $this->load->view('includes/header');       
       $this->load->view('question_details',$data);
       $this->load->view('includes/footer');
   }

    public function post_question()
    {
        $sub= new exam_model;
        $sub-> insert_question();
        redirect(base_url('exam/question_details'));
    }


















   public function create()
   {
      $this->load->view('includes/header');
      $this->load->view('products/create');
      $this->load->view('includes/footer');      
   }
   /**
    * Store Data from this method.
    *
    * @return Response
   */
   public function store()
   {
       $products=new ProductsModel;
       $products->insert_product();
       redirect(base_url('products'));
    }
   /**
    * Edit Data from this method.
    *
    * @return Response
   */
   public function edit($id)
   {
       $product = $this->db->get_where('products', array('id' => $id))->row();
       $this->load->view('includes/header');
       $this->load->view('products/edit',array('product'=>$product));
       $this->load->view('includes/footer');   
   }
   /**
    * Update Data from this method.
    *
    * @return Response
   */
   public function update($id)
   {
       $products=new ProductsModel;
       $products->update_product($id);
       redirect(base_url('products'));
   }
   /**
    * Delete Data from this method.
    *
    * @return Response
   */
   public function delete($id)
   {
       $this->db->where('id', $id);
       $this->db->delete('products');
       redirect(base_url('products'));
   }
}