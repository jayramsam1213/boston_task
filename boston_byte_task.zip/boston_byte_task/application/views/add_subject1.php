<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Add Subject
        <small>Add / </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Subject Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form"  action="<?php echo base_url() ?>exam/post_subject" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="fname">Subject Code</label>
                                        <input type="text" class="form-control required"   name="sub_code" >
                                    </div>
                                    
                                </div>
                             </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile">Subject Name</label>
                                        <input type="text" class="form-control required " name="sub_name" >
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
               </div>    
    </section>
    
</div><!-- 
<script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script> -->