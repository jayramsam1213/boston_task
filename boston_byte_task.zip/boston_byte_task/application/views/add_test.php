<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Add test
        <small>Add / </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter test Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form"  action="<?php echo base_url() ?>exam/post_test" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                              <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="role">enter Subject Id</label>
                                        <select class="form-control required" id="role" name="sub_id">  
                                            <option value="0">Select type</option>
                                            <option value="10">web</option>
                                            <option value="11">java</option>
                                             <option value="12">os</option>
                                             <option value="14">subject</option>
                                            
                                        </select>
                                    </div>
                                </div>   
                                </div> 

                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="fname">Test Name</label>
                                        <input type="text" class="form-control required"   name="test_name" >
                                    </div>
                                    
                                </div>
                             </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile">No Question</label>
                                        <input type="text" class="form-control required " name="total_que" >
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
               </div>    
    </section>
    
</div><!-- 
<script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script> -->