
<?php $CI =& get_instance();
$CI->load->model('exam_model');
$result = $CI->exam_model->get_test()

 ?>



<div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Add question
        <small>Add / </small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter question Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form"  action="<?php echo base_url() ?>exam/post_question" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                              <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="role">Select test Id</label>
                                        <select class="form-control required" id="role" name="test_id">  
                                                                                       
                                            
                                            <option value="0">Select test Name</option>
                                             <?php foreach ($result as $row ) { ?>

                                            <option value="<?php echo $row->test_id; ?>"><?php echo $row->test_name; ?></option>
                                        <?php } ?>
                                            
                                        </select>
                                    </div>
                                </div>   
                                </div> 

                            <div class="row">
                                <div class="col-md-8">                                
                                    <div class="form-group">
                                        <label for="fname">Question Name</label>
                                        <input type="text" class="form-control required"   name="question" >
                                    </div>
                                    
                                </div>
                             </div>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="mobile">Enter option1</label>
                                        <input type="text" class="form-control required " name="ans1" >
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="mobile">Enter option2</label>
                                        <input type="text" class="form-control required " name="ans2" >
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="mobile">Enter option3</label>
                                        <input type="text" class="form-control required " name="ans3" >
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="mobile">Enter option4</label>
                                        <input type="text" class="form-control required " name="ans4" >
                                    </div>
                                </div>
                            </div>
                              <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="mobile">currect ans</label>
                                        <input type="text" class="form-control required " name="currect_ans" >
                                    </div>
                                </div>
                            </div>
                             <div class="row">
                              <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="role">Select paranet quesion id</label>
                                        <select class="form-control required" id="role" name="sub_qus_id">  
                                            <option value="0">Select question Name</option>
                                            <?php foreach ($data as $d) {   ?>
                                            <option value="<?php echo $d->que_id; ?>"><?php echo $d->que_desc; ?></option>
                                            <?php   }
                       ?>

                                            
                                        </select>
                                    </div>
                                </div>   
                                </div> 





                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
               </div>    
    </section>
    
</div><!-- 
<script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script> -->