<?php
class Exam_model extends CI_Model{
    
    public function get_subject()
    {
        if(!empty($this->input->get("search"))){
          $this->db->like('title', $this->input->get("search"));
          $this->db->or_like('description', $this->input->get("search")); 
        }
        $query = $this->db->get("mst_subject");
        return $query->result();
    }
     public function get_test()
    {
       
        $query = $this->db->get("mst_test");
        return $query->result();
    }
      public function get_question()
    {
       
        $query = $this->db->get("mst_question");
        return $query->result();
    }



   function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    public function insert_subject()
    {    
        $data = array(
            'sub_id' => $this->input->post('role'),
            'sub_name' => $this->input->post('sub_name')
        );
        return $this->db->insert('mst_subject', $data);
    }
     public function insert_test()
    {    
        $data = array(
            'sub_id' => $this->input->post('sub_id'),
            'test_name' => $this->input->post('test_name'),
            'total_que' => $this->input->post('total_que'),
        );
        return $this->db->insert('mst_test', $data);
    }
    public function insert_question()
    {
        $data = array(
            // 'que_id' =>$this->input->post('sub_id') ,
            'test_id' =>$this->input->post('test_id') ,
            'que_desc' =>$this->input->post('question') ,
            'ans1' =>$this->input->post('ans1') ,
            'ans2' =>$this->input->post('ans2') ,
            'ans3' =>$this->input->post('ans3') ,
            'ans4' =>$this->input->post('ans4') ,
            'true_ans' =>$this->input->post('currect_ans') ,
            'sub_qus_id' =>$this->input->post('sub_qus_id') 
         );
        return $this->db->insert('mst_question', $data);
    }

    public function update_product($id) 
    {
        $data=array(
            'title' => $this->input->post('title'),
            'description'=> $this->input->post('description')
        );
        if($id==0){
            return $this->db->insert('products',$data);
        }else{
            $this->db->where('id',$id);
            return $this->db->update('products',$data);
        }        
    }
}
?>